#include "InfaredSensor.h"

InfaredSensor::InfaredSensor(int sensorPin) : sensorPin(sensorPin) {}

void InfaredSensor::init(){
  pinMode(sensorPin, INPUT);
}

bool InfaredSensor::status(){
  return !digitalRead(sensorPin);
}