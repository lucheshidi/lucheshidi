#pragma once
#include <Arduino.h>
#include <Motor.h>

class Robot{
  private:
    const Motor motor1;
    const Motor motor2;

  public:
    Robot(Motor motor1, Motor motor2);

    void init();
    void rotate(bool direction, float speed);
    void move(bool direction, float speed);
    void stop();
};