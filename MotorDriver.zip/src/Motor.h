#pragma once
#include <Arduino.h>

class Motor{
  private:
    const int motorPin1;
    const int motorPin2;
    const float bias;

  public:
    Motor(int motorPin1, int motorPin2, float bias = 1.0);

    void init();
    void rotate(bool direction, float speed);
    void stop();
};