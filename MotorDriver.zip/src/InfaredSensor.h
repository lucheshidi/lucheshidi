#pragma once
#include <Arduino.h>

class InfaredSensor{
  private:
    const int sensorPin;

  public:
    InfaredSensor(int sensorPin);

    void init();
    bool status();
};