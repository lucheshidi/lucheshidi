#include "Motor.h"

Motor::Motor(int motorPin1, int motorPin2, float bias) : motorPin1(motorPin1), motorPin2(motorPin2), bias(bias) {}

void Motor::init(){
    pinMode(motorPin1, OUTPUT);
    pinMode(motorPin2, OUTPUT);
}

void Motor::rotate(bool direction, float speed){
    speed = speed * bias;
    if (direction){
        analogWrite(motorPin1, speed);
        analogWrite(motorPin2, 0);
    }
    else{
        analogWrite(motorPin1, 0);
        analogWrite(motorPin2, speed);
    }
}

void Motor::stop(){
    digitalWrite(motorPin1, HIGH);
    digitalWrite(motorPin2, HIGH);
}

