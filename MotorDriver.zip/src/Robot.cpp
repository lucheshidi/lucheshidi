#include "Robot.h"

Robot::Robot(Motor motor1, Motor motor2) : motor1(motor1), motor2(motor2) {}

void Robot::init(){
    motor1.init();
    motor2.init();
}

void Robot::rotate(bool direction, float speed){
    if(direction){
        motor1.rotate(true, speed);
        motor2.rotate(false, speed);
    }
    else{
        motor1.rotate(false, speed);
        motor2.rotate(true, speed);
    }
}

void Robot::move(bool direction, float speed){
    if(direction){
        motor1.rotate(true, speed);
        motor2.rotate(true, speed);
    }
    else{
        motor1.rotate(false, speed);
        motor2.rotate(false, speed);
    }
}

void Robot::stop(){
    motor1.stop();
    motor2.stop();
}


